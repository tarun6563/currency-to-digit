﻿using CurrencyToDigit.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace CurrencyToDigit.Controllers
{
    public class IndexController : Controller
    {
        //
        // GET: /Index/

        public ActionResult Index()
        {
            
            return View();
        }

        [HttpPost]
        public ActionResult Index(Currency currency)
        {
            
            if (ModelState.IsValid)
            {
                string currencyInWords = new Common().changeToWords(currency.CurrencyDigit.ToString());
                currency.CurrencyText = currencyInWords;
            }
            

            return View("Index", currency);
        }

    }
}
