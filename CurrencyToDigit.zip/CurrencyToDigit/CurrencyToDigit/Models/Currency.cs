﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Web;

namespace CurrencyToDigit.Models
{
    public class Currency
    {
        public string UserName { get; set; }

        public string CurrencyText { get; set; }

        [DataType(DataType.Currency)]
        public double CurrencyDigit { get; set; }
    }
}